//B"H
// background.js

// Example background script
console.log('Background script loaded');

// Example: Listen for browser action clicks (e.g., extension button)
chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["aiify.js",'content.js']
  });
});
