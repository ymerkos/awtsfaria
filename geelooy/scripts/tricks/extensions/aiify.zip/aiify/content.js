//B"H
// content.js
console.log(`B"H`);
function injectScript (src) {
    const s = document.createElement('script');
    s.src = chrome.runtime.getURL(src);
    s.onload = () => s.remove();
    (document.head ||   document.documentElement).append(s);
    console.log("YO!",s.src,window.aiify)
    
}

//injectScript("aiify.js");

// Function to create and inject AIify UI onto the page
function injectAiifyUI() {
  // Create a div for AIify UI
  const aiifyDiv = document.createElement('div');
  aiifyDiv.style.position = 'fixed';
  aiifyDiv.style.top = '20px';
  aiifyDiv.style.left = '20px';
  aiifyDiv.style.backgroundColor = 'white';
  aiifyDiv.style.padding = '10px';
  aiifyDiv.style.border = '1px solid black';
  aiifyDiv.style.zIndex = '9999';

  // Construct AIify UI elements
  aiifyDiv.innerHTML = `
    <div class="awtsmoosAiPics">
    <h3>Awtsmoos AIify Pictures</h3>
    <label for="promptInput">Prompt:</label>
    <textarea rows=8 id="promptInput" placeholder="Enter prompt"></textarea><br><br>
    <label for="timesInput">Times:</label>
    <input type="number" id="timesInput" placeholder="Enter number of times"><br><br>
    <div id="prog"></div><br><br>
    <button id="runAiify">Run</button>
    </div>
    <style>
    /* 1. Styling the container */
    .awtsmoosAiPics {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f0f0f0;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        font-family: Arial, serif;
    }

    /* 2. Styling the heading */
    .awtsmoosAiPics h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
       
    }

    /* 3. Styling form elements */
    .awtsmoosAiPics label {
        display: block;
        font-size: 16px;
        color: #666;
        margin-bottom: 6px;
    }

    .awtsmoosAiPics textarea, .awtsmoosAiPics input[type="number"] {
        width: 100%;
        padding: 10px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-bottom: 10px;
        box-sizing: border-box; /* Ensure padding and border are included in width */
    }

    /* 4. Styling the progress bar */
    .awtsmoosAiPics #prog {
        min-height: 10px;
        background-color: #ddd;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    /* 5. Styling the button */
    .awtsmoosAiPics button {
        display: block;
        width: 100%;
        padding: 12px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .awtsmoosAiPics button:hover {
        background-color: #45a049;
    }

    /* 6. Responsive design */
    @media (max-width: 768px) {
        .awtsmoosAiPics {
            padding: 10px;
        }
        .awtsmoosAiPics button {
            font-size: 14px;
        }
    }
</style>

  `;

  // Append AIify UI to the body of the page
  document.body.appendChild(aiifyDiv);

  // Event listener for Run button
  document.getElementById('runAiify').addEventListener('click', async () => {
    const prompt = document.getElementById('promptInput').value;
    var prog =  document.getElementById("prog")
    const times = parseInt(document.getElementById('timesInput').value, 10);

    // Call your existing aiify function with prompt and times
    await aiify({ prompt, times, progress({message}) {
        console.log(message,2)
        prog.innerText = message
    } });
  });
}

document.addEventListener("DOMContentLoaded", function() {
    // Now it's safe to access document.body
    console.log(document.body);
      injectAiifyUI()
});
