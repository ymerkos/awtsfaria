//B"H
// content.js
console.log(`B"H`);

var minimized = false
var promptVal;
var times;


// Function to create and inject AIify UI onto the page
function injectAiifyUI() {
  // Create a div for AIify UI
  const aiifyDiv = document.createElement('div');
  aiifyDiv.style.position = 'fixed';
  aiifyDiv.style.top = '20px';
  aiifyDiv.style.left = '20px';
  aiifyDiv.style.backgroundColor = 'white';
  aiifyDiv.style.padding = '10px';
  aiifyDiv.style.border = '1px solid black';
  aiifyDiv.style.zIndex = '9999';

  // Construct AIify UI elements
  aiifyDiv.innerHTML = `
    <div class="awtsmoosAiPics">
    <div class="headerAwts">
        
        <div class="controls">
            <button id="minimizeBtn">-</button>
            <button id="maximizeBtn" style="display: none;">+</button>
        </div>
    </div>
    <div class="contentAwts">
        <h3>Awtsmoos AIify Pictures</h3>
        <label for="promptInput">Prompt:</label>
        <textarea rows="8" id="promptInput" placeholder="Enter prompt"></textarea><br><br>
        <label for="timesInput">Times:</label>
        <input type="number" id="timesInput" placeholder="Enter number of times"><br><br>
        <div id="prog"></div><br><br>
        <button id="runAiify">Run</button>
    </div>
</div>
    <style>
    /* 1. Styling the container */
    .awtsmoosAiPics {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        background-color: #f0f0f0;
        border: 1px solid #ccc;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        font-family: Times, serif;
    }

    .awtsmoosAiPics.minimized .contentAwts {
        height: 0px;
        width: 0px;
        padding: 0px;
        overflow: hidden;
    }

    .awtsmoosAiPics .headerAwts {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap:20px;
    }
    
    .awtsmoosAiPics .contentAwts {
        display: block;
    }
    
    .awtsmoosAiPics.minimized {
        padding:0px;
    }
    
    .awtsmoosAiPics.minimized .content {
        display: none;
    }

    /* 2. Styling the heading */
    .awtsmoosAiPics h3 {
        font-size: 24px;
        color: #333;
        margin-bottom: 20px;
        text-align: center;
       
    }

    /* 3. Styling form elements */
    .awtsmoosAiPics label {
        display: block;
        font-size: 16px;
        color: #666;
        margin-bottom: 6px;
    }

    .awtsmoosAiPics textarea, .awtsmoosAiPics input[type="number"] {
        width: 100%;
        padding: 10px;
        font-size: 14px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-bottom: 10px;
        box-sizing: border-box; /* Ensure padding and border are included in width */
    }

    /* 4. Styling the progress bar */
    .awtsmoosAiPics #prog {
        min-height: 10px;
        background-color: #ddd;
        padding:26px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    /* 5. Styling the button */
    .awtsmoosAiPics button {
        display: block;
        width: 100%;
        padding: 12px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    .awtsmoosAiPics button:hover {
        background-color: #45a049;
    }

    /* 6. Responsive design */
    @media (max-width: 768px) {
        .awtsmoosAiPics {
            padding: 10px;
        }
        .awtsmoosAiPics button {
            font-size: 14px;
        }
    }
</style>

  `;

  // Append AIify UI to the body of the page
  document.body.appendChild(aiifyDiv);
    const div = document.querySelector('.awtsmoosAiPics');
    const minimizeBtn = document.getElementById('minimizeBtn');
    const maximizeBtn = document.getElementById('maximizeBtn');
    var pi = document.getElementById('promptInput')
    var cont = document.querySelector(".contentAwts")
    minimizeBtn.addEventListener('click', function() {
        div.classList.add('minimized');
        minimizeBtn.style.display = 'none';
        maximizeBtn.style.display = 'inline-block';
        minimized=true
        promptVal = pi.value;
        updateLS()
    });

    maximizeBtn.addEventListener('click', function() {
        div.classList.remove('minimized');
        maximizeBtn.style.display = 'none';
        minimizeBtn.style.display = 'inline-block';
        minimized=false
        promptVal = pi.value;
        updateLS()
    });

    checkLS()
  // Event listener for Run button
  document.getElementById('runAiify').addEventListener('click', async () => {
    promptVal = pi.value;
    var prog =  document.getElementById("prog")
    times = parseInt(document.getElementById('timesInput').value, 10);
    updateLS()
    // Call your existing aiify function with prompt and times
    await aiify({ prompt:promptVal, times, progress({message}) {
        console.log(message,2)
        prog.innerText = message
    } });
  });
}

function checkLS() {
    if(localStorage.prompt) {
        promptVal = localStorage.prompt;
        document.getElementById('promptInput').value = promptVal;
    }

    if(localStorage.times) {
        times = localStorage.times;
        document.getElementById('timesInput').value = times;
    }

    if(localStorage.minimized) {
        minimized = localStorage.minimized;
        const minimizeBtn = document.getElementById('minimizeBtn');
        minimizeBtn.click();
    }
}

function updateLS() {
    localStorage.prompt=promptVal;
    localStorage.times=times;
    localStorage.minimized=minimized
}

document.addEventListener("DOMContentLoaded", function() {
    // Now it's safe to access document.body
    console.log(document.body);
      injectAiifyUI()
});
