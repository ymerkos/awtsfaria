// B"H

// content.js
chrome.runtime.onMessage.addListener(async (message) => {
  if (message.params && message.headers) {
    const { params, headers } = message;

    try {
      // Construct the request URL with parameters
      const url = new URL("https://chatgpt.com/backend-api/synthesize");
      Object.keys(params).forEach((key) => url.searchParams.append(key, params[key]));
      url.searchParams.append("awtsmoos","true")

      // Prepare headers for the fetch request, including the custom header
      const fetchHeaders = new Headers();
      Object.entries(headers).forEach(([key, value]) => fetchHeaders.append(key, value));
      fetchHeaders.append("Awtsmoos-Bypass", "true");  // Custom header to avoid re-interception

      // Make the fetch request and handle the response blob
      const response = await fetch(url, { method: "GET", headers: fetchHeaders });
      const blob = await response.blob();

      // Download the blob automatically
      const urlObject = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = urlObject;
      anchor.download = "BH_" + Date.now()+"_"+ "synthesized_audio.aac";
      anchor.click();

      // Revoke the object URL to free up memory
      URL.revokeObjectURL(urlObject);
    } catch (error) {
      console.error("Failed to download audio:", error);
    }
  }
});