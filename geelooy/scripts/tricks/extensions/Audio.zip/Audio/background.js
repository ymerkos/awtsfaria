// B"H

// background.js
chrome.webRequest.onBeforeSendHeaders.addListener(
  function (details) {
    const url = new URL(details.url);
    console.log(w=url,6)
    
    // Check if the request is targeting the synthesize endpoint
    if (url.pathname.startsWith("/backend-api/synthesize")) {
  

      // Extract URL parameters and request headers
      const params = Object.fromEntries(url.searchParams.entries());
      
          // Look for the custom header to avoid re-interception
      const hasCustomHeader = params.awtsmoos

      // Ignore requests containing the custom header
      if (hasCustomHeader) {
        return;
      }
      
      const headers = details.requestHeaders.reduce((acc, header) => {
        acc[header.name] = header.value;
        return acc;
      }, {});

      // Send parameters and headers to the content script
      chrome.tabs.query({ url: "*://chatgpt.com/*" }, (tabs) => {
        tabs.forEach((tab) => {
          chrome.tabs.sendMessage(tab.id, { params, headers });
        });
      });
    }
  },
  { urls: ["*://chatgpt.com/backend-api/synthesize*"] },
  ["requestHeaders"]
);