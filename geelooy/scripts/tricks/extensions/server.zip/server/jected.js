//B"H
console.log(
`B"H
Welcome`
)
if(!window.awtsmoosFetch) {
	window.awtsmoosFetch =
	function awtsFetch(url, options={}, after = "text") {
	    class Awts {
	        constructor(ob) {
	            this.result = ob.result;
	            this.cookies = ob.cookies;
	            this.headers = ob.headers
	        }
	        async text() {
	            return this.result;
	        }
	        async json() {
	            return JSON.parse(this.result);
	        }
	    }
	    return new Promise(r => {
			var id = "BH_"+Date.now() +
			"_" + Math.random();
			function msg(e) {
				if(
					e.data.from == "background"
				) {
					window.removeEventListener("message", msg);
	                r(new Awts(e.data));
	            }
			}
			
	        window.addEventListener("message", msg);
			
	        postMessage({
	            action: "fetch",
	            data: {
	                url, 
	                options,
	                after,
					
	            },
				id
	        })
	    })
	}
}