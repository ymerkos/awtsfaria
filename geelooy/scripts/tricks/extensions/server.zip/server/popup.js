//B"H
document.getElementById("startServer").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "startServer" }, (response) => {
    document.getElementById("status").textContent = "Status: Running";
    console.log(response.message);
  });
});

document.getElementById("stopServer").addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "stopServer" }, (response) => {
    document.getElementById("status").textContent = "Status: Stopped";
    console.log(response.message);
  });
});
