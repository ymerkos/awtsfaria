// B"H
console.log('B"H');

chrome.webNavigation.onCompleted.addListener(async details => {
    chrome.scripting.executeScript({
        target: { tabId: details.tabId },
        files: ['awtsmoosContent.js']
    });
});

class ChromePortManager {
  constructor() {
    this.ports = {}; // Store active ports
    this.events = {}; // Store event listeners
    this.init();
  }

  // Event listener registration
  on(event, listener) {
    if (typeof event === 'object') {
      // If event is an object, register multiple listeners at once
      for (const [key, fn] of Object.entries(event)) {
        this.on(key, fn);
      }
    } else {
      // Ensure the event array is initialized
      if (!this.events[event]) {
        this.events[event] = [];
      }
      // Add listener to the event
      this.events[event].push(listener);
    }
  }

  // Emit events to listeners
  emit(event, ...data) {
    if (this.events[event]) {
      this.events[event].forEach(async listener => await listener(...data));
    }
  }

  // Initialize connection handlers
  init() {
    chrome.runtime.onConnect.addListener((port) => {
      console.log("New connection", port);
      this.handleNewConnection(port);
    });

    chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
      console.log("Received message", message);
      await this.handleMessage(message, sendResponse);
    });
  }

  // Handle messages received from a port
  async handlePortMessage(port, message) {
    console.log("Handling port message", message);

    // Emit event for the message if there's an action for it
    if (message.action) {
      this.emit(message.action, message, port); // Emit dynamic event based on action
    }

    // Handle port-specific registration
    if (message.name) {
      this.registerPortByName(port, message.name);
    }

    // Handle sending message to another port
    if (message.to) {
      await this.sendMessageToPort(message);
    }

    // Auto-reply to the port (if needed)
    if (message.reply) {
      this.reply(port, message.reply);
    }
  }

  // Auto-reply function to send messages back to the correct port
  reply(port, data) {
    console.log("Sending reply to port", port);
    if (port) {
      port.postMessage({
        ...data,
        from: data.name || 'background'
      });
      console.log("Reply sent:", data);
    }
  }

  // Handle incoming messages from the background script or other sources
  async handleMessage(message, sendResponse) {
    switch (message.command) {
      case 'send':
        console.log("Handling send command", message);
        await this.sendMessageToPort(message);
        sendResponse({status: "Message sent"});
        break;

      default:
        console.log("Unhandled command", message.command);
        sendResponse({error: "Unknown command"});
    }
  }

  // Method for port-specific registration
  registerPortByName(port, name) {
    if (!this.ports[name]) {
      console.log("New port registered:", name);
      this.ports[name] = port;
    }
  }

  // Method to send a message to another port
  async sendMessageToPort(message) {
    const { to } = message;
    const targetPort = this.ports[to];
    if (targetPort) {
      try {
        targetPort.postMessage({
          ...message,
          from: message.name || message.from,
        });
        console.log("Message sent to port", to);
      } catch (e) {
        console.error("Error sending message to port", e);
        this.onPortDisconnect(targetPort); // Attempt to disconnect on error
      }
    }
  }

  // Port disconnection handler
  onPortDisconnect(port) {
    const { name } = port;
    delete this.ports[name];
    console.log("Deleted port with name:", name);
  }

  // Handle new connection (optional: for handling port setup)
  handleNewConnection(port) {
    console.log("Handling new connection", port);
    port.onMessage.addListener(async (message) => {
      await this.handlePortMessage(port, message);
    });
    
    // Listen for the port being disconnected
    port.onDisconnect.addListener(() => {
      console.log("Port disconnected:", port);
      this.onPortDisconnect(port);
    });
  }
}

// Instantiate the class
const portManager = new ChromePortManager();

// Example usage of dynamic event listener registration
portManager.on('startChatGPT', (data) => {
  console.log("ChatGPT started with data:", data);
});

portManager.on("eval", async (message, port) => {
	var c = message?.data?.code;
	try {
		var res = await simpleEval(c)
		portManager.reply(port, {
			result: res
		})
	} catch(e) {
		portManager.reply(port, {
			error: e.stack
		})
	}
	portManager.reply(port, {
		
	})
})
// Trigger an event with 'customEvent' action and reply
portManager.on('customEvent', async (message, port) => {
    console.log('Custom event received:', message, port);

    // Simulate some logic, then send a reply
    await new Promise(resolve => setTimeout(resolve, 500));  // Simulating async work

    // Send a reply back to the port
	message.LOL = 1234
    portManager.reply(port, { status: 'Processed', data: message });
});

portManager.on("fetch", async (msg, port) => {
	var d = msg?.data;
	var url = d?.url
	var opts = d?.options;
	var func = d?.after;
	
	try {
		var parst = new URL(url)
		var cooks = await getCookieString(parst.host)
		var res = await fetch(url, opts);
		var f = await res?.[func]();
		var headers = [];
		for (const pair of res.headers.entries()) {
			headers.push({
				[pair[0]]:pair[1]
			})
		  // console.log(pair[0]+ ': '+ pair[1]);
		}
		portManager.reply(port, {
			result: f,
			headers,
			cookies: cooks
		})
	} catch(e) {
		portManager.reply(port, {
			error: e.stack
		})
	}
})


// Register multiple events at once
portManager.on({
  'someAction': (data) => {
    console.log("Some action occurred with data:", data);
  },
  'anotherAction': (data) => {
    console.log("Another action occurred with data:", data);
  },
  'newEvent': (data) => {
    console.log("A new event triggered with data:", data);
  }
});

// Dynamically handle an event and perform action
portManager.on("newEvent", (data) => {
  console.log("Handled newEvent with dynamic data:", data);
});

function getCookieString(domain) {
    return new Promise(r => 
    chrome.cookies.getAll({domain}, f=> {
        var str = f.map(w=>
            w.name+"="+
            w.value+"; "
        ).join("");
        r({string: str, cookies: f})
    }))
}

async function start() {
	var r = await fetch("https://awtsmoos.com/api/social");
	var f = await (r).json()
	console.log(f)
}


async function simpleEval(expression, context = this) {
    // Helper function to evaluate arithmetic expressions manually
    function evaluateArithmetic(expr) {
        let tokens = expr.replace(/\s+/g, '').split(/([+\-*/()])/).filter(Boolean);

        let index = 0;

        function parseExpression() {
            let result = parseTerm();
            while (tokens[index] === '+' || tokens[index] === '-') {
                const operator = tokens[index++];
                const nextTerm = parseTerm();
                result = applyOperator(result, nextTerm, operator);
            }
            return result;
        }

        function parseTerm() {
            let result = parseFactor();
            while (tokens[index] === '*' || tokens[index] === '/') {
                const operator = tokens[index++];
                const nextFactor = parseFactor();
                result = applyOperator(result, nextFactor, operator);
            }
            return result;
        }

        function parseFactor() {
            let token = tokens[index++];
            if (token === '(') {
                const result = parseExpression();
                if (tokens[index++] !== ')') {
                    throw new Error('Mismatched parentheses');
                }
                return result;
            } else if (isNumber(token)) {
                return parseFloat(token);
            } else if (isString(token)) {
                return token.slice(1, -1);  // Remove quotes from string literals
            } else {
                throw new Error('Unexpected token: ' + token);
            }
        }

        function applyOperator(left, right, operator) {
            if (operator === '+') {
                return left + right;
            } else if (operator === '-') {
                return left - right;
            } else if (operator === '*') {
                return left * right;
            } else if (operator === '/') {
                return left / right;
            } else {
                throw new Error('Unknown operator: ' + operator);
            }
        }

        function isNumber(value) {
            return !isNaN(value);
        }

        function isString(value) {
            return value.startsWith('"') && value.endsWith('"');
        }

        return parseExpression();
    }

    // Helper function to handle function calls, including awaiting promises
    async function evaluateFunctionCall(fn, args, context) {
        const func = context[fn];
        if (func && typeof func === 'function') {
            const result = await func.apply(context, args);
            return result;
        } else {
            throw new Error(`Function ${fn} not found in context`);
        }
    }

    // Helper function to handle chained `await` expressions
    async function evaluateAwaitExpression(expr) {
        // Match an await expression like `await (await fetch(...)).json()`
        const awaitRegex = /await\s*\((.*)\)/g;
        let matches;
        while ((matches = awaitRegex.exec(expr)) !== null) {
            const innerExpr = matches[1]; // The part inside the parentheses
            const result = await simpleEval(innerExpr, context); // Evaluate inner expression
            expr = expr.replace(matches[0], `(${result})`); // Replace with evaluated result
        }
        return expr;
    }

    // Main evaluation function
    async function parseExpression(expression) {
        // First, handle chained `await` expressions
        expression = await evaluateAwaitExpression(expression);

        // Handle function calls like fetch("url") or log("hello")
        const fnRegex = /\w+\s*\(.*?\)/;
        if (fnRegex.test(expression)) {
            const match = expression.match(/(\w+)\((.*)\)/);
            const fn = match[1];
            const args = match[2].split(',').map(arg => arg.trim());
            const parsedArgs = args.map(arg => {
                if (arg.match(/^\d+(\.\d+)?$/)) {
                    return parseFloat(arg);  // Parse numeric arguments
                } else if (arg.startsWith('"') && arg.endsWith('"')) {
                    return arg.slice(1, -1);  // Parse string arguments
                }
                return arg;  // Return as is for now (could be more complex)
            });

            return await evaluateFunctionCall(fn, parsedArgs, context);
        }

        // If we don't have a function call or `await`, then evaluate the expression as an arithmetic or string expression
        if (/^[\d+\-*\/\s()]+$/.test(expression)) {
            return evaluateArithmetic(expression);
        } else {
            throw new Error('Invalid expression');
        }
    }

    // Execute the expression
    try {
        return await parseExpression(expression);
    } catch (e) {
        console.error('Error executing the expression:', e);
    }
}


//start()